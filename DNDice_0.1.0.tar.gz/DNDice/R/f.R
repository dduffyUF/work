##' Roll a dice of your choosing (Description)
##'
##' Roll a dice of your choosing and get a randomly generated number as the result (Details)
##' @title Roll dice of your choosing
##' @param m Dice of your choosing
##' @return Dice Result
##' @author Dustin
##' @export
##' @examples
DiceRoll <- function(m) {if(m=='D4'){
  return(sample(c(123, 124, 134, 234), 1, replace=TRUE))
} else {
  if(m =='D6'){
    return(sample(1:6, 1, replace=TRUE))
  } else {
    if(m =='D8'){
      return(sample(1:8, 1, replace=TRUE))
    }
    else {
      if(m =='D10_1'){
        return(sample(0:9, 1, replace=TRUE))
      }
      else {
        if(m =='D10_10'){
          return(sample(c(00, 10, 20, 30, 40, 50, 60, 70, 80, 90), 1, replace=TRUE))
        }
        else {
          if(m =='D12'){
            return(sample(1:12, 1, replace=TRUE))
          }
          else {
            if(m =='D20'){
              return(sample(1:20, 1, replace=TRUE))
            }
          }
        }
      }

    }
  }
}
}
